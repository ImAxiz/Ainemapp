export const STORE_NAME = 'ithemes-security/firewall';
export const path = '/ithemes-security/v1/firewall/rules';
