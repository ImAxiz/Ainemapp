export const STORE_NAME = 'ithemes-security/modules';
